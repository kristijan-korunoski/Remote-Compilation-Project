#include "allfunctions.h"

int cube(int x)
{
    return x * x * x;
}

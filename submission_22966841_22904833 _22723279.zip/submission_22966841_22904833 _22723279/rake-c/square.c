#include "allfunctions.h"

int square(int x)
{
    return x * x;
}
